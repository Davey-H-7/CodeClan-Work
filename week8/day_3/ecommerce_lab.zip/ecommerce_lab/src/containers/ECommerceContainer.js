import React, {useState, useEffect} from 'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Home from '../components/Home';
import ProductList from '../components/ProductList';
import Basket from '../components/Basket';
import Header from '../components/Header';
import styled from 'styled-components'

const ECommerceContainer = () => {

    const [products, setProducts] = useState([
        {name: 'Brick', price: 2},
        {name: 'Cement', price: 5},
        {name: 'Tile', price: 1}
    ])

    const [basket, setBasket] =useState([])

    const[total, setTotal] =useState(0)

    useEffect (() => {
        const totalSum = basket.reduce((total, product) => total + product.price, 0)
        setTotal(totalSum)
    }, [basket])


    const addToBasket = (product) => {
      const copiedBasket = [...basket, product]
      setBasket(copiedBasket)
    }

    const removeFromBasket = (index) => {
        const copiedBasket = [...basket]
        copiedBasket.splice(index, 1)
        setBasket(copiedBasket)
        
      
    }

    return (  
        <Router>
            <Header/>
            <Routes>
                <Route path="/" element={<Home/>} />
                <Route path ="/products" element ={<ProductList products ={products} addToBasket={addToBasket}/>} />
                <Route path ="/basket" element = {<Basket basket = {basket} total ={total} removeFromBasket={removeFromBasket}/>} />
            </Routes>

        </Router>


    );
}
 
export default ECommerceContainer;