import React from 'react';
import {Link} from 'react-router-dom'
import styled from 'styled-components'

const NavBar = styled.ul`
list-style-type: none;
display:flex;
justify-content: space-evenly;
background-color: orange;
margin: 0;
padding: 1em;
text-decoration: none;
`

const StyledLink = styled(Link)`
text-decoration: none;
color: white;
padding: 1em;

&:hover {
background-color: blue;
}
`


const Header = () => {
    return ( 
        <NavBar>
            <li>
                <StyledLink to= "/">Home</StyledLink>
            </li>
            <li>
                <StyledLink to= "/products">Products</StyledLink>
            </li>
            <li>
                <StyledLink to= "/basket">Basket</StyledLink>
            </li>
        </NavBar>
     );
}
 
export default Header;