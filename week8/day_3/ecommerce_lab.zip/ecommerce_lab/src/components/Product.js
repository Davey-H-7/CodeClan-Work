import React from 'react';
import styled from 'styled-components'

const Button = styled.button`
font-size: 1em;
padding: 0.5em;
`

const ProductDiv = styled.div`
display: flex;
flex-direction: column;
text-align: center;

`

const Product = ({product, addToBasket}) => {

    const handleClick = () => {
        addToBasket(product)
    }

    return (
        <ProductDiv>
        <p>{product.name} costs £{product.price}</p>
        <Button onClick={handleClick}>Add to basket</Button>
        </ProductDiv>
     );
}
 
export default Product;