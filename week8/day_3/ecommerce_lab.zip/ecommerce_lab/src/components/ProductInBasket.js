import React from 'react';

const ProductInBasket = ({product, index, removeFromBasket}) => {

    const handleClick = (event) => {
        removeFromBasket(event.target.value)
    }
    return ( 
        <div>
            <p>{product.name} - £{product.price}</p>
            <button value = {index} onClick={handleClick}>Remove basket</button>
        </div>
     );
}
 
export default ProductInBasket;