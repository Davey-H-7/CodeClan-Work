import React from 'react';
import Product from './Product';
import styled from 'styled-components'


const ProductsDiv = styled.div`
display: flex;
justify-content: space-evenly;
flex-wrap: wrap;
`

const Title = styled.h1`

text-align: center;`



const ProductList = ({products, addToBasket}) => {
    
    const productNodes = products.map((product, index) => {
        return <Product product={product} key={index} addToBasket={addToBasket}/>
        })
    
    return ( 
        <>
        <Title> All Products </Title>
        <ProductsDiv>
            {productNodes}
        </ProductsDiv>
        
        </>
     );
}
 
export default ProductList;