import React from 'react';
import ProductInBasket from './ProductInBasket';

const Basket = ({basket, total, removeFromBasket}) => {
    const productNodes = basket.map((product, index) => {
    return <ProductInBasket product={product} key={index} index = {index} removeFromBasket={removeFromBasket}/>
    })

return ( 
    <>
    <h1> This is the basket</h1>
    
        {productNodes}
        <p> Basket total = £{total}</p>
    </>
 );
}
 
export default Basket;