import React from 'react';
import ECommerceContainer from './containers/ECommerceContainer';

import './App.css';

function App() {
  return (
    <ECommerceContainer/>
  );
}

export default App;
